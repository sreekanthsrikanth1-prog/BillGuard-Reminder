# BillGuard Reminder - Android APK Project

BillGuard Reminder is a privacy-safe Android bill and recharge reminder app.

## Version 1 features
- Add bills, recharge, EMI, rent, Wi-Fi, insurance, and other due dates.
- Paid / unpaid tracker.
- Monthly summary.
- Tamil + English app interface and voice alerts inside WebView.
- Native Android background reminder scheduling through AlarmManager.
- Reminder notifications before due date and on due date.
- Boot receiver to reschedule reminders after phone restart.
- No bank login, no SMS reading, no OTP, no UPI PIN, no contacts permission.

## Package
`com.billguard.reminder`

## Build methods
1. Android Studio: open this folder and build APK.
2. GitHub Actions: upload this folder to a GitHub repository and run the workflow named `Build BillGuard Debug APK`.

## Store note
Before Play Store release, test on multiple Android phones and prepare store listing, screenshots, privacy policy, and closed testing.
