package com.billguard.reminder;

import android.content.Context;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

public class NativeBridge {
    private final Context context;

    public NativeBridge(Context context) {
        this.context = context.getApplicationContext();
    }

    @JavascriptInterface
    public void syncBills(String billsJson, String settingsJson) {
        ReminderScheduler.saveAndSchedule(context, billsJson, settingsJson);
    }

    @JavascriptInterface
    public void toast(String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }
}
