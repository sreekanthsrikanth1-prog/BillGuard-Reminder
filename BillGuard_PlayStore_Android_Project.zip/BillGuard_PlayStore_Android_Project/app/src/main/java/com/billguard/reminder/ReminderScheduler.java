package com.billguard.reminder;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public class ReminderScheduler {
    private static final String PREFS = "billguard_native_prefs";
    private static final String KEY_BILLS = "bills_json";
    private static final String KEY_SETTINGS = "settings_json";
    private static final String KEY_REQUEST_CODES = "request_codes";

    public static void saveAndSchedule(Context context, String billsJson, String settingsJson) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        prefs.edit().putString(KEY_BILLS, billsJson).putString(KEY_SETTINGS, settingsJson).apply();
        scheduleFromStorage(context);
    }

    public static void scheduleFromStorage(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String billsJson = prefs.getString(KEY_BILLS, "[]");
        String settingsJson = prefs.getString(KEY_SETTINGS, "{}");
        cancelExisting(context, prefs);

        Set<String> requestCodes = new HashSet<>();
        try {
            JSONArray bills = new JSONArray(billsJson);
            JSONObject settings = new JSONObject(settingsJson);
            String reminderTime = settings.optString("reminderTime", "08:00");
            String currency = settings.optString("currency", "₹");

            for (int i = 0; i < bills.length(); i++) {
                JSONObject bill = bills.getJSONObject(i);
                if (bill.optBoolean("paid", false)) continue;

                String id = bill.optString("id", "bill_" + i);
                String name = bill.optString("name", "Bill");
                String dueDate = bill.optString("dueDate", "");
                int remindBefore = bill.optInt("remindBefore", 3);
                double amount = bill.optDouble("amount", 0);
                if (dueDate.length() == 0) continue;

                long reminderMillis = calculateMillis(dueDate, reminderTime, -remindBefore);
                long dueMillis = calculateMillis(dueDate, reminderTime, 0);
                String amountText = currency + String.format(Locale.US, "%.0f", amount);

                if (reminderMillis > System.currentTimeMillis()) {
                    int code = requestCode(id + "_before");
                    scheduleAlarm(context, code, reminderMillis, "Bill due soon", name + " " + amountText + " is due on " + dueDate);
                    requestCodes.add(String.valueOf(code));
                }
                if (dueMillis > System.currentTimeMillis()) {
                    int code = requestCode(id + "_due");
                    scheduleAlarm(context, code, dueMillis, "Bill due today", name + " " + amountText + " is due today.");
                    requestCodes.add(String.valueOf(code));
                }
            }
        } catch (Exception ignored) {
        }
        prefs.edit().putStringSet(KEY_REQUEST_CODES, requestCodes).apply();
    }

    private static long calculateMillis(String isoDate, String time, int addDays) throws Exception {
        if (time == null || !time.matches("\\d{2}:\\d{2}")) time = "08:00";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
        Date date = sdf.parse(isoDate + " " + time);
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DAY_OF_YEAR, addDays);
        return cal.getTimeInMillis();
    }

    private static void scheduleAlarm(Context context, int requestCode, long whenMillis, String title, String body) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;
        Intent intent = new Intent(context, ReminderReceiver.class);
        intent.putExtra("title", title);
        intent.putExtra("body", body);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMillis, pendingIntent);
        } else {
            alarmManager.set(AlarmManager.RTC_WAKEUP, whenMillis, pendingIntent);
        }
    }

    private static void cancelExisting(Context context, SharedPreferences prefs) {
        Set<String> codes = prefs.getStringSet(KEY_REQUEST_CODES, new HashSet<String>());
        if (codes == null) return;
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;
        for (String codeText : codes) {
            try {
                int code = Integer.parseInt(codeText);
                PendingIntent pi = PendingIntent.getBroadcast(
                        context,
                        code,
                        new Intent(context, ReminderReceiver.class),
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                );
                alarmManager.cancel(pi);
            } catch (Exception ignored) {
            }
        }
    }

    private static int requestCode(String key) {
        return Math.abs(key.hashCode());
    }
}
