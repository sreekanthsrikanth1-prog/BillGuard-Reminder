BillGuard Reminder - First Working PWA Version

How to use on Android:
1. Download and unzip BillGuard_Reminder_App.zip.
2. Open index.html in Chrome.
3. Add a sample bill or add your own bill.
4. Use Enable notifications and Test voice.
5. If hosted online, Chrome can install it to home screen as a PWA.

Important reminder limitation:
This PWA version can alert reliably only when the app is open/active. For full background reminders like a real Android app, convert it into a native Android app and add Android notification scheduling.

Privacy:
This app does not ask for bank login, SMS permission, contacts, OTP, UPI PIN, or payment details. It stores bill names, amounts, dates, and notes locally on the user's device.
